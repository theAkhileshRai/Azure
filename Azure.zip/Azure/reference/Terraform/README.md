* Notes for later:
Create separate folders for environment specific  (e.g.production)
Add the tf settings to that folder
add DR to that folder 
need some DR locals vars
