# Front Door Premium Migration

This deployment migrates the existing legacy CDN configuration from `C:\repo\test-repo\reference\Terraform` to Azure Front Door Premium.

## Migration Overview

### Original Configuration (Legacy CDN)
- **SKU**: `Standard_Microsoft` 
- **Resources**: 
  - CDN Profile: `azurerm_cdn_profile.cdn`
  - CDN Endpoints: `azurerm_cdn_endpoint.projectexdnn` and `azurerm_cdn_endpoint.microfrontend`
  - Custom Domains: `azurerm_cdn_endpoint_custom_domain`

### New Configuration (Premium Front Door)
- **SKU**: `Premium_AzureFrontDoor`
- **Resources**:
  - Front Door Profile: `azurerm_cdn_frontdoor_profile`
  - Endpoints: `azurerm_cdn_frontdoor_endpoint`
  - Origin Groups: `azurerm_cdn_frontdoor_origin_group`
  - Origins: `azurerm_cdn_frontdoor_origin`
  - Routes: `azurerm_cdn_frontdoor_route`
  - Custom Domains: `azurerm_cdn_frontdoor_custom_domain`
  - WAF Policy: `azurerm_cdn_frontdoor_firewall_policy`
  - Security Rules: `azurerm_cdn_frontdoor_rule_set`

## Key Migrations

### 1. Asset Endpoint Migration
**Original**: 
- Endpoint: `${region_code}projectexdnn${env_code}stgsitecdn`
- Origin Path: `/assets`
- Custom Domain: `assets-embark-dev.ehr.com`

**New**:
- Endpoint: `${regioncodeprefix}assets`
- Origin Path: `/assets`
- Custom Domain: `assets-embark-dev.ehr.com`

### 2. Microfrontend Endpoint Migration
**Original**:
- Endpoint: `${region_code}microfrontend${env_code}stgsitecdn`
- Origin Path: `/pex-microfrontend`
- Custom Domain: `microfrontend-embark-dev.ehr.com`

**New**:
- Endpoint: `${regioncodeprefix}microfrontend`
- Origin Path: `/pex-microfrontend`
- Custom Domain: `microfrontend-embark-dev.ehr.com`

### 3. Security Features Migration
**Original Features**:
- Global delivery rules for security headers
- Delivery rules for HTTPS redirect
- CORS configuration via delivery rules

**New Features**:
- WAF Policy with managed rules
- Security Rule Set with response header modifications
- Enhanced security with Premium features

### 4. Headers Migration
All security headers from the original configuration are preserved:
- `Strict-Transport-Security`
- `Referrer-Policy`
- `X-Content-Type-Options`
- `X-Frame-Options`
- `Cache-Control`
- `Permissions-Policy`
- `Content-Security-Policy`

## Deployment

### Prerequisites
1. Azure subscription with appropriate permissions
2. Terraform >= 1.0
3. AzureRM provider ~> 3.100

### Variables
Set the following variables either in `terraform.tfvars` or as environment variables:
- `cdn_contributor_spn` - Service principal for CDN contributor role
- `dns_zone_id` - DNS zone ID for custom domain validation

### Commands
```bash
# Initialize Terraform
terraform init

# Plan the deployment
terraform plan

# Apply the deployment
terraform apply
```

## Post-Migration Steps

### 1. DNS Update
Update DNS records to point to new Front Door endpoints:
- `assets-embark-dev.ehr.com` → New Front Door endpoint
- `microfrontend-embark-dev.ehr.com` → New Front Door endpoint

### 2. Testing
1. Verify endpoints are accessible
2. Test custom domains
3. Validate security headers
4. Test CORS functionality
5. Verify WAF is blocking malicious requests

### 3. Monitoring
- Set up monitoring for Front Door metrics
- Configure alerts for WAF blocks
- Monitor performance improvements

## Rollback Plan
If issues occur, you can temporarily revert DNS to point back to the original CDN endpoints while troubleshooting.

## Benefits of Migration
1. **Enhanced Security**: WAF protection with managed rules
2. **Better Performance**: Global network with edge locations
3. **Advanced Features**: Route-based configuration, rule sets
4. **Compliance**: Premium features for enterprise requirements
5. **Monitoring**: Advanced analytics and diagnostics

## Resource Mapping

| Original Resource | New Resource | Purpose |
|------------------|--------------|---------|
| `azurerm_cdn_profile.cdn` | `azurerm_cdn_frontdoor_profile.profile` | Main CDN service |
| `azurerm_cdn_endpoint.projectexdnn` | `azurerm_cdn_frontdoor_endpoint.assets` | Assets delivery |
| `azurerm_cdn_endpoint.microfrontend` | `azurerm_cdn_frontdoor_endpoint.microfrontend` | Microfrontend delivery |
| Delivery rules | `azurerm_cdn_frontdoor_rule_set` | Security headers |
| N/A | `azurerm_cdn_frontdoor_firewall_policy` | WAF protection |
| N/A | `azurerm_cdn_frontdoor_security_policy` | Security policy association |