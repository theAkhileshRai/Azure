# Azure Front Door Premium Migration Project

This repository contains Terraform modules and deployments for migrating from legacy Azure CDN (Standard_Microsoft) to Azure Front Door Premium.

## 📁 Project Structure

```
test-repo/
├── modules/
│   └── frontdoor-premium/          # Reusable Front Door Premium module
│       ├── main.tf                 # Main Front Door resources
│       ├── security.tf             # WAF and security rules
│       ├── variables.tf            # Module variables
│       └── outputs.tf              # Module outputs
├── deployments/
│   ├── dev/                        # Development environment
│   │   ├── main.tf                 # Dev-specific configuration
│   │   ├── variables.tf            # Dev variables
│   │   ├── terraform.tfvars        # Dev values
│   │   ├── outputs.tf              # Dev outputs
│   │   └── README.md               # Dev deployment guide
│   └── prod/                       # Production environment
│       ├── main.tf                 # Prod-specific configuration
│       ├── variables.tf            # Prod variables
│       ├── terraform.tfvars        # Prod values
│       └── outputs.tf              # Prod outputs
└── reference/
    └── Terraform/                  # Original legacy CDN configuration
        ├── cdn.tf                  # Legacy CDN resources
        ├── locals.tf               # Original locals
        └── variables.environment.tfvars  # Original variables
```

## 🔄 Migration Overview

### From Legacy CDN
- **SKU**: `Standard_Microsoft`
- **Configuration**: Single CDN profile with multiple endpoints
- **Security**: Basic delivery rules for headers
- **Management**: Manual configuration with limited automation

### To Premium Front Door
- **SKU**: `Premium_AzureFrontDoor`
- **Configuration**: Modular approach with endpoints, origins, routes
- **Security**: WAF policies, managed rules, comprehensive security headers
- **Management**: Full Infrastructure as Code with Terraform modules

## 🚀 Key Features

### Enhanced Security
- ✅ WAF (Web Application Firewall) with managed rule sets
- ✅ Custom WAF rules for rate limiting and blocking
- ✅ Comprehensive security headers (HSTS, CSP, etc.)
- ✅ SSL/TLS termination with managed certificates

### Performance Improvements
- ✅ Global edge locations with Microsoft's backbone
- ✅ Advanced caching with compression
- ✅ Origin grouping and health probes
- ✅ Intelligent routing

### Operational Excellence
- ✅ Infrastructure as Code with Terraform
- ✅ Environment-specific configurations
- ✅ Reusable modules for consistency
- ✅ Comprehensive monitoring and alerting

## 📋 Migration Mapping

| Component | Legacy CDN | Premium Front Door | Status |
|-----------|------------|-------------------|--------|
| **Profile** | `azurerm_cdn_profile.cdn` | `azurerm_cdn_frontdoor_profile.profile` | ✅ Migrated |
| **Assets Endpoint** | `azurerm_cdn_endpoint.projectexdnn` | `azurerm_cdn_frontdoor_endpoint.assets` | ✅ Migrated |
| **Microfrontend Endpoint** | `azurerm_cdn_endpoint.microfrontend` | `azurerm_cdn_frontdoor_endpoint.microfrontend` | ✅ Migrated |
| **Custom Domains** | `azurerm_cdn_endpoint_custom_domain` | `azurerm_cdn_frontdoor_custom_domain` | ✅ Migrated |
| **Security Headers** | Global delivery rules | `azurerm_cdn_frontdoor_rule_set` | ✅ Enhanced |
| **WAF Protection** | ❌ Not available | `azurerm_cdn_frontdoor_firewall_policy` | ✅ New feature |
| **HTTPS Redirect** | Delivery rules | `azurerm_cdn_frontdoor_rule` | ✅ Migrated |

## 🛠️ Prerequisites

### Required Tools
- [Terraform](https://terraform.io) >= 1.0
- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/) >= 2.0
- Azure subscription with appropriate permissions

### Required Permissions
- Contributor access to target subscription
- DNS zone management permissions (for custom domains)
- Key Vault access (for managed identity)

### Required Resources
- Azure DNS zone for custom domain validation
- User-assigned managed identity for Key Vault access
- Service principal with CDN Contributor role

## 🚀 Quick Start

### 1. Clone and Initialize
```bash
git clone <repository-url>
cd test-repo
```

### 2. Configure Environment Variables
```bash
# Required for deployment
export ARM_SUBSCRIPTION_ID="your-subscription-id"
export ARM_CLIENT_ID="your-client-id"
export ARM_CLIENT_SECRET="your-client-secret"
export ARM_TENANT_ID="your-tenant-id"

# Optional: Set specific values
export TF_VAR_cdn_contributor_spn="your-service-principal-id"
export TF_VAR_dns_zone_id="/subscriptions/.../dnszones/ehr.com"
```

### 3. Deploy Development Environment
```bash
cd deployments/dev
terraform init
terraform plan
terraform apply
```

### 4. Deploy Production Environment
```bash
cd ../prod
terraform init
terraform plan
terraform apply
```

## 🔧 Configuration

### Module Configuration
The `frontdoor-premium` module supports extensive customization:

```hcl
module "frontdoor_premium" {
  source = "../../modules/frontdoor-premium"
  
  # Basic configuration
  frontdoor_name         = "my-frontdoor"
  resource_group_name    = "my-rg"
  location              = "Central US"
  
  # Endpoints
  enable_assets_endpoint        = true
  enable_microfrontend_endpoint = true
  
  # Security
  enable_waf_policy      = true
  enable_security_headers = true
  waf_mode              = "Prevention"
  
  # Custom domains
  assets_custom_domain        = "assets.example.com"
  microfrontend_custom_domain = "app.example.com"
}
```

### Environment-Specific Values
Each environment can override defaults in `terraform.tfvars`:

```hcl
# Development
frontdoor_waf_mode = "Detection"
storage_assets_web_endpoint = "devstorageaccount.z19.web.core.windows.net"

# Production  
frontdoor_waf_mode = "Prevention"
storage_assets_web_endpoint = "prodstorageaccount.z19.web.core.windows.net"
```

## 🔒 Security Features

### WAF Protection
- **Managed Rule Sets**: OWASP Core Rule Set, Bot Manager
- **Custom Rules**: Rate limiting, IP blocking, geo-blocking
- **Actions**: Block, Allow, Log, Redirect

### Security Headers
- `Strict-Transport-Security` - HSTS enforcement
- `Content-Security-Policy` - XSS protection
- `X-Frame-Options` - Clickjacking protection
- `X-Content-Type-Options` - MIME sniffing protection
- `Referrer-Policy` - Referrer information control
- `Permissions-Policy` - Feature policy control

### CORS Configuration
Configurable CORS origins for different endpoints:
```hcl
cors_allowed_origins = [
  "https://app.example.com",
  "https://admin.example.com"
]
```

## 📊 Monitoring and Alerts

### Built-in Metrics
- Request count and latency
- Cache hit ratio
- Origin health status
- WAF metrics and blocks

### Recommended Alerts
1. **High 4xx/5xx Error Rate**: Alert when error rate > 5%
2. **Origin Health**: Alert when origins are unhealthy
3. **WAF Blocks**: Monitor blocked requests
4. **Cache Miss Rate**: Alert when cache hit ratio < 80%

## 🔄 Migration Process

### Phase 1: Preparation
1. ✅ Create Front Door Premium module
2. ✅ Set up environment-specific deployments
3. ✅ Configure security policies
4. ✅ Test in development environment

### Phase 2: Development Migration
1. Deploy to development environment
2. Update DNS records for dev domains
3. Validate functionality and performance
4. Run security tests

### Phase 3: Production Migration
1. Deploy to production environment
2. Update DNS records with blue-green approach
3. Monitor performance and security metrics
4. Complete cutover and decommission legacy CDN

## 🛡️ Rollback Strategy

In case of issues during migration:

1. **DNS Rollback**: Revert DNS records to legacy CDN
2. **Parallel Running**: Keep legacy CDN running during transition
3. **Monitoring**: Set up alerts for immediate issue detection
4. **Testing**: Comprehensive testing before DNS cutover

## 📚 Additional Resources

- [Azure Front Door Documentation](https://docs.microsoft.com/en-us/azure/frontdoor/)
- [Terraform AzureRM Provider](https://registry.terraform.io/providers/hashicorp/azurerm/latest)
- [Migration Best Practices](./docs/migration-best-practices.md)
- [Troubleshooting Guide](./docs/troubleshooting.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📞 Support

For issues and questions:
- Create an issue in this repository
- Contact the infrastructure team
- Review the troubleshooting guide

---

**Note**: This migration maintains all existing functionality while adding enhanced security and performance features. The modular approach ensures consistency across environments and makes future updates manageable.